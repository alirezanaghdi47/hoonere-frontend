// Exports the "emoticons" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/emoticons')
//   ES2015:
//     import 'tinymce/modules/emoticons'
require('./plugin.js');