// Exports the "autolink" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/autolink')
//   ES2015:
//     import 'tinymce/modules/autolink'
require('./plugin.js');