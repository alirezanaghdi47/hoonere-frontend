// Exports the "media" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/media')
//   ES2015:
//     import 'tinymce/modules/media'
require('./plugin.js');