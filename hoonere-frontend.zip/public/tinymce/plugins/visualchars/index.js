// Exports the "visualchars" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/visualchars')
//   ES2015:
//     import 'tinymce/modules/visualchars'
require('./plugin.js');