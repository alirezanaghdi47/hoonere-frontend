// Exports the "directionality" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/directionality')
//   ES2015:
//     import 'tinymce/modules/directionality'
require('./plugin.js');