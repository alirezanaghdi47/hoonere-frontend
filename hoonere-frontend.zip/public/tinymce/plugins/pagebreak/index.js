// Exports the "pagebreak" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/pagebreak')
//   ES2015:
//     import 'tinymce/modules/pagebreak'
require('./plugin.js');