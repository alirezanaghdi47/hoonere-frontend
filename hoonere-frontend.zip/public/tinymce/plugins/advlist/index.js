// Exports the "advlist" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/advlist')
//   ES2015:
//     import 'tinymce/modules/advlist'
require('./plugin.js');