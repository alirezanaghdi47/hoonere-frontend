// Exports the "help" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/help')
//   ES2015:
//     import 'tinymce/modules/help'
require('./plugin.js');