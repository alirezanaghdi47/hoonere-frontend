// Exports the "visualblocks" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/visualblocks')
//   ES2015:
//     import 'tinymce/modules/visualblocks'
require('./plugin.js');