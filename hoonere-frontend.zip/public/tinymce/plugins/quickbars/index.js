// Exports the "quickbars" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/quickbars')
//   ES2015:
//     import 'tinymce/modules/quickbars'
require('./plugin.js');