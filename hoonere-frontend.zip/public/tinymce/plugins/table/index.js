// Exports the "table" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/table')
//   ES2015:
//     import 'tinymce/modules/table'
require('./plugin.js');