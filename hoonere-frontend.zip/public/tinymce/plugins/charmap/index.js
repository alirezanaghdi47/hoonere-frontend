// Exports the "charmap" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/charmap')
//   ES2015:
//     import 'tinymce/modules/charmap'
require('./plugin.js');