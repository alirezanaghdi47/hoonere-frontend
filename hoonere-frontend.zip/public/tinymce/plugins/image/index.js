// Exports the "image" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/image')
//   ES2015:
//     import 'tinymce/modules/image'
require('./plugin.js');