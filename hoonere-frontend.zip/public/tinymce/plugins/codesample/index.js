// Exports the "codesample" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/codesample')
//   ES2015:
//     import 'tinymce/modules/codesample'
require('./plugin.js');