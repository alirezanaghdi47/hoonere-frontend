// Exports the "insertdatetime" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/insertdatetime')
//   ES2015:
//     import 'tinymce/modules/insertdatetime'
require('./plugin.js');