// Exports the "link" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/link')
//   ES2015:
//     import 'tinymce/modules/link'
require('./plugin.js');