// Exports the "autosave" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/autosave')
//   ES2015:
//     import 'tinymce/modules/autosave'
require('./plugin.js');