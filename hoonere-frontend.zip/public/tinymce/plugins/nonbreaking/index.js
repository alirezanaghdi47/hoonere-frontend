// Exports the "nonbreaking" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/nonbreaking')
//   ES2015:
//     import 'tinymce/modules/nonbreaking'
require('./plugin.js');