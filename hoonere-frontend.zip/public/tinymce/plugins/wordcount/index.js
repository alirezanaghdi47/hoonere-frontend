// Exports the "wordcount" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/wordcount')
//   ES2015:
//     import 'tinymce/modules/wordcount'
require('./plugin.js');