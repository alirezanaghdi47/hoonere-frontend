// Exports the "accordion" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/accordion')
//   ES2015:
//     import 'tinymce/modules/accordion'
require('./plugin.js');