// Exports the "searchreplace" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/searchreplace')
//   ES2015:
//     import 'tinymce/modules/searchreplace'
require('./plugin.js');