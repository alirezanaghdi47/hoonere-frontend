// Exports the "lists" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/lists')
//   ES2015:
//     import 'tinymce/modules/lists'
require('./plugin.js');