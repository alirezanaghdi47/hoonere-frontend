// Exports the "save" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/save')
//   ES2015:
//     import 'tinymce/modules/save'
require('./plugin.js');