// Exports the "code" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/code')
//   ES2015:
//     import 'tinymce/modules/code'
require('./plugin.js');