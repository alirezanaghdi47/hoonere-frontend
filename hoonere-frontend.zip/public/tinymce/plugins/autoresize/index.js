// Exports the "autoresize" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/autoresize')
//   ES2015:
//     import 'tinymce/modules/autoresize'
require('./plugin.js');