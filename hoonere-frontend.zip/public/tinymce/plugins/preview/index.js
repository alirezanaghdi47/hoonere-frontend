// Exports the "preview" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/preview')
//   ES2015:
//     import 'tinymce/modules/preview'
require('./plugin.js');