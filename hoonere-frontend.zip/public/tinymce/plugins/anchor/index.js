// Exports the "anchor" modules for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/modules/anchor')
//   ES2015:
//     import 'tinymce/modules/anchor'
require('./plugin.js');