// modules
import Button from "@/modules/Button";
import Form from "@/modules/Form";
import Textarea from "@/modules/Textarea";
import ImageInput from "@/modules/ImageInput";

const ResumeFormData = ({readMyProfileAction ,updateOccupationForm , updateOccupationAction}) => {
    return (
        <>
            <div className="card w-100">
                <div className="card-body d-flex flex-column gap-5">
                    <div className="row gy-2">
                        <div className="col-lg-4">
                            <Form.Label
                                label="رزومه ( عکس یا pdf )"
                                size="sm"
                                color="dark"
                            />
                        </div>

                        <div className="col-lg-8">
                            <Form.Group>
                                <ImageInput
                                    id="resume_file"
                                    name="resume_file"
                                    preview={readMyProfileAction.data?.data?.user_info?.resume_file}
                                    value={updateOccupationForm.values.resume_file}
                                    onChange={(value) => updateOccupationForm.setFieldValue("resume_file", value)}
                                />

                                <Form.Error
                                    error={updateOccupationForm.errors.resume_file}
                                    touched={updateOccupationForm.touched.resume_file}
                                />
                            </Form.Group>
                        </div>
                    </div>

                    <div className="row gy-2">
                        <div className="col-lg-4">
                            <Form.Label
                                label="رزومه متنی"
                                size="sm"
                                color="dark"
                                required
                            />
                        </div>

                        <div className="col-lg-8">
                            <Form.Group>
                                <Textarea
                                    id="resume_text"
                                    name="resume_text"
                                    value={updateOccupationForm.values.resume_text}
                                    onChange={(value) => updateOccupationForm.setFieldValue("resume_text", value)}
                                />

                                <Form.Error
                                    error={updateOccupationForm.errors.resume_text}
                                    touched={updateOccupationForm.touched.resume_text}
                                />
                            </Form.Group>
                        </div>
                    </div>
                </div>
            </div>

            <div className="d-flex justify-content-end align-items-center gap-5 w-100">
                <Button
                    color="success"
                    onClick={updateOccupationForm.handleSubmit}
                    isLoading={updateOccupationAction.isPending}
                >
                    ذخیره تغییرات
                </Button>
            </div>
        </>
    )
}

export default ResumeFormData;